﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Steeve
{
    class Program
    {
        static void Main(string[] args)
        {
            (new List<int>())
                .Set(a => { for (int i = 326496; i < 649632//2147483647
                                                      ; i++) a.Add(i); })
                .Set(a => "Привет мир 1".WriteLine())
                .AsParallel()
                .Select(a =>
                    (new
                    {
                        Value = a
                        ,
                        Del = (new List<int>()).Set(b =>
                        {
                            System.Threading.Tasks.Parallel.For(1, a, i => { if (a % i == 0) b.Add(i); });
                        }).ToList()
                    }
                //.Set(b=>(b.Value.ToString() +System.String.Join(" ", b.Del.Select(c=>c.ToString()))).WriteLine())
                //.Set(b=> b.Del.ToArray().ToString().WriteLine())
                ))
                
                .AsParallel()
                .Where(a => a.Del.Count > 70)//.Set(a => a.Count().ToString().WriteLine())
                //.Where(a => a.Del.Where(b=>b!=1).Min()>10).Set(a => a.Count().ToString().WriteLine())
                .Where(a => a.Del.Where(b => b % 2 == 0).Count() == a.Del.Where(b => b % 2 != 0).Count())
                .Select(a => new { Value = a.Value,Min=a.Del.Where(b => b>1000).Min()})
                //.Set(a => a.Count().ToString().WriteLine())
                //.Select(a=>new {Value=a.Value, DelString=a.Del.ToArray().ToString() })
                .ToList()
                .ForEach(a=>a.ToString().WriteLine())

                ;
            ;
            "Вырубай машину спать пора".WriteLine().ReadLine();

        }
    }
}
