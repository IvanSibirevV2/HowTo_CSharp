﻿//qweqw =)
namespace System
{
    public class EXT_delegate
    {
        public delegate MyDel MyDel(System.String _STR, int __Value);
    }
}
//Привет мир 0
//Привет мир 1
//Привет мир 2
//Привет мир 3
//Привет мир 4
//Привет мир 5
//Привет мир 6
//Привет мир 7
//Привет мир 8
//Microsoft.VisualStudio.TextTemplating53E8AB195DE477B62E0DCEFE2AA8A8D4EB3DEEB9DE3C356DAD6E41EC029E648923DF8AA3BBAF90B06F555FC5A497DEF58B3FA530917DE4D7C232583AB1126B9B.GeneratedTextTransformation
