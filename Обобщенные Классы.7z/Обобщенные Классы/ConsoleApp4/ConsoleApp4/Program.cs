﻿using System;

namespace ConsoleApp4
{
    public class Program
    {
        public static void Main(string[] args)
        {
            Perenoska < Cat> _Perenoska_Cat = new Perenoska<Cat>();
            _Perenoska_Cat.Set_Pet_T(new Cat() { Name = "Archi" });
            System.Console.WriteLine(_Perenoska_Cat.PetInPerenoska.Name);
            System.Console.WriteLine(_Perenoska_Cat.PetInPerenoska.GetType().ToString());
            System.Console.WriteLine("########################################");
            Perenoska<Dog> _Perenoska_Dog = new Perenoska<Dog>();
            _Perenoska_Dog.Set_Pet_T(new Dog() { Name = "TyZik" });
            System.Console.WriteLine(_Perenoska_Dog.PetInPerenoska.Name);
            System.Console.WriteLine(_Perenoska_Dog.PetInPerenoska.GetType().ToString());
            System.Console.WriteLine("########################################");
            Perenoska<Pet> _Perenoska_Pet = new Perenoska<Pet>();
            _Perenoska_Pet.Set_Pet_T((Pet)(new Dog() { Name = "TyZik" }));
            //_Perenoska_Pet.Set_Pet_T(new Dog() { Name = "TyZik" });
            System.Console.WriteLine(_Perenoska_Pet.PetInPerenoska.Name);
            System.Console.WriteLine(_Perenoska_Pet.PetInPerenoska.GetType().ToString());
            System.Console.WriteLine("########################################");

            Console.WriteLine("Hello World!");
            System.Console.ReadLine();
        }
    }
    public abstract class Perenoska
    {
        public virtual System.Object Get_Pet() { return 0; }
        public virtual Perenoska Set_Pet(System.Object Pet) { return this; }
    }
    public class Perenoska<T> : Perenoska //where T : Cat
    {
        public T PetInPerenoska;
        public T Get_Pet_T() { return this.PetInPerenoska; }
        public Perenoska Set_Pet_T(T Pet) { this.PetInPerenoska = Pet; return this; }

        public override System.Object Get_Pet() { return (System.Object)this.PetInPerenoska; }
        public override Perenoska Set_Pet(System.Object Pet) { this.PetInPerenoska = (T)Pet; return this; }
    }
    public class Pet 
    {
        public System.String Name= "";
    }
    public class Cat
    {
        public System.String Name = "";
    }
    public class Dog: Pet 
    {
        //public System.String Name = "";
    }
}
