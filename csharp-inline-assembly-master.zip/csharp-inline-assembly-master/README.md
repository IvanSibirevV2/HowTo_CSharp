# Inline Assembly in C#
Inline Assembly Demonstration in C# using Fasm.NET and Process.NET

Visit [my blog](https://esozbek.me/inline-assembly-in-csharp-and-dotnet/) for more.
